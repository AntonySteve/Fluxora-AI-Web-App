import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Globe, 
  ChevronDown, 
  ArrowRight, 
  ArrowLeft,
  X, 
  Check, 
  Sparkles,
  BookOpen,
  Activity,
  Hexagon,
  Layers,
  CircleDot
} from "lucide-react";

export default function App() {
  const [activeNav, setActiveNav] = useState("About");
  const [currentPage, setCurrentPage] = useState<"hero" | "get-started">("hero");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "", project: "" });
  const [videoUrl, setVideoUrl] = useState<string>("");

  React.useEffect(() => {
    fetch("/api/video-url")
      .then((res) => res.json())
      .then((data) => {
        if (data.url) {
          setVideoUrl(data.url);
        }
      })
      .catch((err) => {
        console.error("Error retrieving video:", err);
        setVideoUrl("https://assets.mixkit.co/videos/preview/mixkit-fluid-amber-and-orange-swirling-liquid-40742-large.mp4");
      });
  }, []);

  // Navigation Links
  const navLinks = [
    { name: "Features", hasDropdown: true },
    { name: "How It Works", hasDropdown: false },
    { name: "About", hasDropdown: false },
    { name: "Product", hasDropdown: false },
    { name: "Blogs", hasDropdown: false },
  ];

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email) {
      setFormSubmitted(true);
      setTimeout(() => {
        setIsModalOpen(false);
        setFormSubmitted(false);
        setFormData({ name: "", email: "", project: "" });
      }, 2500);
    }
  };

  return (
    <div 
      id="fluxora-hero-root" 
      className="min-h-screen text-white relative overflow-hidden font-sans selection:bg-orange-500/30 selection:text-orange-200"
    >
      {/* Background Video Player */}
      {videoUrl && (
        <div className="fixed inset-0 -z-30 overflow-hidden bg-black pointer-events-none">
          <video
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            className="w-full h-full object-cover transition-opacity duration-1000 opacity-100"
            style={{ transform: 'scale(1.14)', transformOrigin: 'top center' }}
            src={videoUrl}
          />
        </div>
      )}

      {/* Very thin dark vignette overlay to ensure text remains readable without obscuring the background video */}
      <div className="fixed inset-0 bg-black/25 -z-20 pointer-events-none" />

      {/* Ambient background glows */}
      <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full bg-gradient-to-br from-orange-500/10 via-amber-600/5 to-transparent blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[50%] h-[50%] rounded-full bg-gradient-to-tr from-orange-600/5 via-red-500/5 to-transparent blur-[120px] pointer-events-none" />
      
      {/* Subtle Grid overlay */}
      <div className="absolute inset-0 bg-grid-pattern opacity-15 pointer-events-none" />

      {/* HEADER NAVIGATION */}
      <header 
        id="fluxora-header" 
        className="relative z-40 max-w-7xl mx-auto px-6 md:px-8 py-6 flex items-center justify-between"
      >
        {/* Logo */}
        <motion.div 
          id="fluxora-logo"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => setCurrentPage("hero")}
        >
          {/* Custom 3D-like isometric logo mark */}
          <div className="relative w-8 h-8 flex items-center justify-center">
            {/* Background glowing layer */}
            <div className="absolute inset-0 bg-gradient-to-tr from-orange-600 to-amber-400 rounded-lg blur-md opacity-40 group-hover:opacity-75 transition-opacity" />
            <svg 
              className="w-7 h-7 relative z-10 transition-transform duration-500 group-hover:rotate-12" 
              viewBox="0 0 24 24" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Left face */}
              <path d="M4 8L12 3.5V12.5L4 17V8Z" fill="url(#logoGradLeft)" />
              {/* Right face */}
              <path d="M20 8L12 3.5V12.5L20 17V8Z" fill="url(#logoGradRight)" />
              {/* Bottom/Underlay Face */}
              <path d="M4 17L12 21.5L20 17L12 12.5L4 17Z" fill="url(#logoGradBottom)" />
              
              <defs>
                <linearGradient id="logoGradLeft" x1="4" y1="3.5" x2="12" y2="17" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#ff5a1f" />
                  <stop offset="1" stopColor="#e11d48" />
                </linearGradient>
                <linearGradient id="logoGradRight" x1="12" y1="3.5" x2="20" y2="17" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#fbbf24" />
                  <stop offset="1" stopColor="#ea580c" />
                </linearGradient>
                <linearGradient id="logoGradBottom" x1="4" y1="12.5" x2="20" y2="21.5" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#dc2626" />
                  <stop offset="1" stopColor="#9a3412" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <span className="text-2xl font-semibold tracking-tight text-white font-display">
            Fluxora
          </span>
        </motion.div>

        {/* Center Pill Navigation and Right CTA / Back Home Icon Button */}
        {currentPage === "get-started" ? (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <button
              onClick={() => setCurrentPage("hero")}
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-neutral-800 bg-neutral-900/60 hover:bg-neutral-900 hover:border-neutral-700 text-neutral-400 hover:text-white transition-all duration-300 cursor-pointer group text-xs font-semibold uppercase tracking-wider shadow-[0_2px_15px_rgba(249,115,22,0.05)]"
            >
              <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
              <span>Back to Home</span>
            </button>
          </motion.div>
        ) : (
          <>
            {/* Center Pill Navigation */}
            <motion.nav 
              id="fluxora-nav-capsule"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
              className="hidden md:flex items-center gap-1 bg-neutral-950/45 border border-neutral-800/80 p-1 rounded-full backdrop-blur-md relative"
            >
              {navLinks.map((link) => {
                const isActive = activeNav === link.name && currentPage === "hero";
                return (
                  <button
                    key={link.name}
                    onClick={() => {
                      setActiveNav(link.name);
                      setCurrentPage("hero");
                    }}
                    className={`relative px-4 py-2 text-[13px] font-medium tracking-wide transition-all rounded-full flex items-center gap-1.5 cursor-pointer z-10 ${
                      isActive ? "text-white" : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="activePill"
                        className="absolute inset-0 rounded-full -z-10 border"
                        style={{
                          backgroundColor: "rgba(38, 38, 38, 0.6)",
                          borderColor: "rgba(64, 64, 64, 0.3)"
                        }}
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      />
                    )}
                    <span>{link.name}</span>
                    {link.hasDropdown && (
                      <ChevronDown className="w-3.5 h-3.5 text-neutral-500 group-hover:text-white" />
                    )}
                  </button>
                );
              })}
            </motion.nav>

            {/* Right CTA Button */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            >
              <button 
                id="fluxora-btn-get-started"
                onClick={() => setCurrentPage("get-started")}
                className="bg-white text-black text-[13px] font-semibold px-5 py-2.5 rounded-full hover:bg-neutral-100 transition-all duration-300 shadow-[0_4px_20px_rgba(255,255,255,0.06)] active:scale-95 cursor-pointer"
              >
                Get Started
              </button>
            </motion.div>
          </>
        )}
      </header>

      {/* HERO & GET STARTED PAGES CONTAINER */}
      <AnimatePresence mode="wait">
        {currentPage === "hero" ? (
          <motion.main
            key="hero-page"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.4 }}
            id="fluxora-hero-content" 
            className="relative z-30 max-w-7xl mx-auto px-6 md:px-8 pt-8 md:pt-16 pb-20 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-start"
          >
            {/* LEFT COLUMN: Texts and Actions */}
            <div className="lg:col-span-7 flex flex-col items-start gap-8">
              
              {/* Badge indicator */}
              <motion.div 
                id="fluxora-badge"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="flex items-start gap-3 group"
              >
                <div className="p-2 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-orange-500 group-hover:text-orange-400 group-hover:border-neutral-700 transition-all duration-300">
                  <Globe className="w-4 h-4 animate-pulse" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[12px] uppercase tracking-wider font-semibold text-neutral-400">
                    #1 AI-based platform for
                  </span>
                  <span className="text-[12px] uppercase tracking-wider font-semibold text-neutral-500 group-hover:text-neutral-300 transition-colors">
                    digital transformation
                  </span>
                </div>
              </motion.div>

              {/* Core Large Heading */}
              <motion.div
                id="fluxora-main-heading"
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
                className="w-full text-left"
              >
                <h1 className="text-[44px] sm:text-6xl md:text-7xl lg:text-8xl font-sans font-medium tracking-tight text-white leading-[1.05] flex flex-col">
                  <span>Technology</span>
                  <span className="text-neutral-300 font-light">Crafted for All</span>
                  <span className="flex items-baseline gap-2 flex-wrap">
                    <span className="font-normal text-white">Not</span>
                    <span className="font-serif italic font-normal text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-500 to-orange-500 tracking-wide select-text relative">
                      Machines
                    </span>
                  </span>
                </h1>
              </motion.div>

              {/* Hero Sub-paragraph */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="text-left text-[16px] sm:text-lg md:text-xl text-neutral-400 font-normal leading-relaxed max-w-xl"
              >
                We create clear, intuitive, and accessible digital experiences shaped by real human behavior.
              </motion.p>

              {/* Interactive CTAs */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="flex flex-col sm:flex-row items-start sm:items-center gap-6 md:gap-8 w-full"
              >
                {/* Primary split action button */}
                <button 
                  id="fluxora-btn-primary"
                  onClick={() => setCurrentPage("get-started")}
                  className="group flex items-center bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white rounded-full pl-6 pr-2 py-2 transition-all duration-300 shadow-[0_4px_30px_rgba(249,115,22,0.2)] active:scale-98 cursor-pointer"
                >
                  <span className="text-sm font-semibold tracking-wide mr-4">Get started</span>
                  <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-black group-hover:translate-x-1 group-hover:-translate-y-0.5 transition-transform duration-300">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </button>

                {/* Clients Avatars & Metric */}
                <div 
                  id="fluxora-clients-group"
                  className="flex items-center gap-3.5 group cursor-pointer"
                  onClick={() => setCurrentPage("get-started")}
                >
                  <div className="flex -space-x-3">
                    <img 
                      className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-30 group-hover:translate-x-[-4px] transition-transform" 
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&h=100&q=80" 
                      alt="Client Avatar 1"
                      referrerPolicy="no-referrer"
                    />
                    <img 
                      className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-20 group-hover:scale-105 transition-transform" 
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100&q=80" 
                      alt="Client Avatar 2"
                      referrerPolicy="no-referrer"
                    />
                    <img 
                      className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-10 group-hover:translate-x-[4px] transition-transform" 
                      src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100&q=80" 
                      alt="Client Avatar 3"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-sm font-semibold text-white group-hover:text-orange-400 transition-colors">
                      500+ Happy Clients
                    </span>
                    <span className="text-[11px] text-neutral-500 uppercase tracking-wider font-semibold">
                      Worldwide
                    </span>
                  </div>
                </div>
              </motion.div>

            </div>

            {/* RIGHT COLUMN: Visual Pillars & Performance Metrics */}
            <div className="lg:col-span-5 flex flex-col gap-10 w-full justify-center lg:pt-12">
              
              {/* Stats Cards Section (Two Side-by-Side Cards) */}
              <div 
                id="fluxora-stats-container"
                className="grid grid-cols-2 gap-4 w-full mt-2 relative"
              >
                {/* Watermark text behind stats cards */}
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[140px] font-sans font-black tracking-widest text-neutral-900/10 pointer-events-none select-none z-0">
                  AIM
                </div>

                {/* Card 1: 150+ Projects delivered */}
                <motion.div
                  id="fluxora-stat-card-projects"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.5 }}
                  whileHover={{ y: -4, borderColor: "rgba(249,115,22,0.3)" }}
                  style={{
                    backgroundColor: "rgba(10, 10, 10, 0.4)",
                    borderColor: "rgba(23, 23, 23, 1)"
                  }}
                  className="relative z-10 border rounded-2xl p-6 text-left overflow-hidden transition-all duration-300"
                >
                  {/* Corner Star Accent */}
                  <div className="absolute top-4 right-4 text-orange-500/80 animate-pulse">
                    <span className="text-xl font-bold font-serif">*</span>
                  </div>
                  {/* Radial orange background flare */}
                  <div className="absolute bottom-[-40px] right-[-40px] w-32 h-32 bg-orange-600/5 rounded-full blur-2xl" />

                  <h3 className="text-4xl md:text-5xl font-sans font-medium text-white tracking-tight">
                    150+
                  </h3>
                  <p className="text-[12px] md:text-sm text-neutral-400 font-medium mt-3 uppercase tracking-wider">
                    Projects delivered
                  </p>
                </motion.div>

                {/* Card 2: 98% Client satisfaction */}
                <motion.div
                  id="fluxora-stat-card-satisfaction"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                  whileHover={{ y: -4, borderColor: "rgba(249,115,22,0.3)" }}
                  style={{
                    backgroundColor: "rgba(10, 10, 10, 0.4)",
                    borderColor: "rgba(23, 23, 23, 1)"
                  }}
                  className="relative z-10 border rounded-2xl p-6 text-left overflow-hidden transition-all duration-300"
                >
                  {/* Corner Star Accent */}
                  <div className="absolute top-4 right-4 text-orange-500/80 animate-pulse">
                    <span className="text-xl font-bold font-serif">*</span>
                  </div>
                  {/* Radial orange background flare */}
                  <div className="absolute bottom-[-40px] right-[-40px] w-32 h-32 bg-amber-600/5 rounded-full blur-2xl" />

                  <h3 className="text-4xl md:text-5xl font-sans font-medium text-white tracking-tight">
                    98%
                  </h3>
                  <p className="text-[12px] md:text-sm text-neutral-400 font-medium mt-3 uppercase tracking-wider">
                    Client satisfaction
                  </p>
                </motion.div>
              </div>

              {/* Under-graphic text block */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="flex flex-col items-start text-left pl-2"
              >
                <div className="flex items-center gap-2 text-orange-500 mb-3 font-semibold text-xs uppercase tracking-wider">
                  <span className="w-4 h-[2px] bg-orange-500 inline-block" />
                  <span>Future-First Impact</span>
                </div>
                <p className="text-[14px] sm:text-[15px] text-neutral-400 leading-relaxed font-normal">
                  Building solutions for today that empower digital success and human progress tomorrow.
                </p>
              </motion.div>

            </div>
          </motion.main>
        ) : (
          <motion.main
            key="get-started-page"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.4 }}
            className="relative z-30 max-w-5xl mx-auto px-6 md:px-8 pt-12 md:pt-20 pb-24 flex flex-col items-center text-center animate-fadeIn"
          >
            {/* Pill Header Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-neutral-900/60 border border-neutral-800 mb-6 text-[11px] uppercase tracking-wider font-semibold text-orange-500 hover:text-orange-400 hover:border-neutral-700 transition-all duration-300 shadow-[0_2px_15px_rgba(249,115,22,0.05)]"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse text-orange-500" />
              <span>Innovative Web3 Solutions</span>
            </motion.div>

            {/* Title Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-sans font-medium tracking-tight text-white leading-[1.1] max-w-4xl"
            >
              Revolutionizing finance with <span className="font-serif italic font-normal text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-500 to-orange-500">Web3 technology</span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-neutral-400 text-base sm:text-lg md:text-xl font-normal leading-relaxed max-w-2xl mt-6"
            >
              Experience the future of finance with our innovative Web3 Fintech Startup.
            </motion.p>

            {/* Avatars Stack & Metric */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center gap-4 mt-10"
            >
              <div className="flex -space-x-3">
                <img 
                  className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-50 hover:scale-105 transition-transform" 
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&h=100&q=80" 
                  alt="Client 1"
                  referrerPolicy="no-referrer"
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-40 hover:scale-105 transition-transform" 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100&q=80" 
                  alt="Client 2"
                  referrerPolicy="no-referrer"
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-30 hover:scale-105 transition-transform" 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100&q=80" 
                  alt="Client 3"
                  referrerPolicy="no-referrer"
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-20 hover:scale-105 transition-transform" 
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&h=100&q=80" 
                  alt="Client 4"
                  referrerPolicy="no-referrer"
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-black object-cover relative z-10 hover:scale-105 transition-transform" 
                  src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&h=100&q=80" 
                  alt="Client 5"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="text-sm font-semibold text-neutral-300">
                Trusted already by <span className="text-orange-500 font-bold">1.2M+ users</span>
              </span>
            </motion.div>

            {/* Bento-style Stats Grid Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              style={{
                backgroundColor: "rgba(8, 8, 8, 0.45)",
                borderColor: "rgba(23, 23, 23, 1)"
              }}
              className="w-full max-w-4xl border rounded-3xl mt-16 p-8 md:p-12 relative overflow-hidden text-left"
            >
              {/* Grid backdrop effect inside card */}
              <div 
                className="absolute inset-0 opacity-10 pointer-events-none"
                style={{
                  backgroundImage: "radial-gradient(rgba(249, 115, 22, 0.15) 1px, transparent 1px)",
                  backgroundSize: "20px 20px"
                }}
              />
              <div className="absolute -top-12 -left-12 w-48 h-48 bg-orange-500/5 rounded-full blur-[80px]" />
              <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-amber-500/5 rounded-full blur-[80px]" />

              <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-4 md:divide-x md:divide-neutral-800/80">
                {/* Stat Col 1 */}
                <div className="flex flex-col items-center md:items-start md:pr-8 text-center md:text-left">
                  <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-widest">
                    Global User Base
                  </span>
                  <span className="text-4xl sm:text-5xl font-sans font-bold text-white tracking-tight mt-3 mb-1">
                    +2M
                  </span>
                  <span className="text-xs text-neutral-400 font-medium">
                    Global User Base
                  </span>
                </div>

                {/* Stat Col 2 */}
                <div className="flex flex-col items-center md:items-start md:px-8 text-center md:text-left">
                  <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-widest">
                    Total Transaction Volume
                  </span>
                  <span className="text-4xl sm:text-5xl font-sans font-bold text-white tracking-tight mt-3 mb-1 bg-clip-text bg-gradient-to-r from-orange-400 to-amber-400 text-transparent">
                    +$1B
                  </span>
                  <span className="text-xs text-neutral-400 font-medium">
                    Total Transaction Volume
                  </span>
                </div>

                {/* Stat Col 3 */}
                <div className="flex flex-col items-center md:items-start md:pl-8 text-center md:text-left">
                  <span className="text-[11px] font-semibold text-neutral-500 uppercase tracking-widest">
                    High Speed Processing
                  </span>
                  <span className="text-4xl sm:text-5xl font-sans font-bold text-white tracking-tight mt-3 mb-1">
                    99%
                  </span>
                  <span className="text-xs text-neutral-400 font-medium">
                    Faster Transactions
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Back to Home Navigation Button at Bottom */}
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              onClick={() => setCurrentPage("hero")}
              className="mt-12 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-400 hover:text-orange-500 transition-colors cursor-pointer group"
            >
              <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
              <span>Back to Home</span>
            </motion.button>
          </motion.main>
        )}
      </AnimatePresence>

      {/* PARTNERS LOGOS BAR AT BOTTOM */}
      <footer 
        id="fluxora-partners-container"
        className="relative z-30 max-w-7xl mx-auto px-6 md:px-8 pt-10 pb-16 border-t border-neutral-900/60 flex flex-col md:flex-row items-center justify-between gap-8 md:gap-4"
      >
        <div className="text-neutral-500 text-xs font-semibold uppercase tracking-wider">
          Our Partners
        </div>

        {/* Partners Grid */}
        <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-6 md:gap-x-10 lg:gap-x-14">
          
          {/* Bookstore Logo */}
          <div 
            id="partner-bookstore" 
            className="flex items-center gap-2.5 text-neutral-400 hover:text-white transition-colors duration-300 group cursor-pointer"
          >
            <BookOpen className="w-5 h-5 text-neutral-500 group-hover:text-orange-500 transition-colors" />
            <span className="text-[15px] font-semibold tracking-tight font-display">BookStore</span>
          </div>

          {/* Zantic Logo */}
          <div 
            id="partner-zantic" 
            className="flex items-center gap-2.5 text-neutral-400 hover:text-white transition-colors duration-300 group cursor-pointer"
          >
            <div className="relative w-5 h-5 flex items-center justify-center">
              <Layers className="w-5 h-5 text-neutral-500 group-hover:text-orange-500 transition-colors" />
            </div>
            <span className="text-[15px] font-semibold tracking-tight font-display">zantic</span>
          </div>

          {/* Crona Logo */}
          <div 
            id="partner-crona" 
            className="flex items-center gap-2.5 text-neutral-400 hover:text-white transition-colors duration-300 group cursor-pointer"
          >
            <Hexagon className="w-5 h-5 text-neutral-500 group-hover:text-orange-500 transition-colors" />
            <span className="text-[15px] font-semibold tracking-tight font-display">Crona</span>
          </div>

          {/* Mercury Logo */}
          <div 
            id="partner-mercury" 
            className="flex items-center gap-2.5 text-neutral-400 hover:text-white transition-colors duration-300 group cursor-pointer"
          >
            <Activity className="w-5 h-5 text-neutral-500 group-hover:text-orange-500 transition-colors" />
            <span className="text-[15px] font-semibold tracking-tight font-display">Mercury</span>
          </div>

          {/* Wigge Logo */}
          <div 
            id="partner-wigge" 
            className="flex items-center gap-2.5 text-neutral-400 hover:text-white transition-colors duration-300 group cursor-pointer"
          >
            <CircleDot className="w-5 h-5 text-neutral-500 group-hover:text-orange-500 transition-colors" />
            <span className="text-[15px] font-semibold tracking-tight font-display">Wigge</span>
          </div>

        </div>
      </footer>

      {/* LEAD CONVERSION MODAL */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Modal backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            {/* Modal container */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="relative w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-2xl p-6 md:p-8 z-10 overflow-hidden shadow-[0_10px_50px_rgba(249,115,22,0.15)] text-left"
            >
              {/* Top ambient lights inside modal */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-600/10 rounded-full blur-2xl pointer-events-none" />

              {/* Close button */}
              <button
                onClick={() => setIsModalOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Header */}
              <div className="flex items-center gap-2 text-orange-500 mb-2">
                <Sparkles className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider font-semibold">Transform Today</span>
              </div>
              <h2 className="text-2xl font-semibold text-white tracking-tight">
                Let's Craft Your Experience
              </h2>
              <p className="text-neutral-400 text-sm mt-1 mb-6">
                Connect with our expert design & development engineering team.
              </p>

              {/* Form Content / Success State */}
              {formSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center py-8 text-center"
                >
                  <div className="w-12 h-12 rounded-full bg-orange-500/20 border border-orange-500 flex items-center justify-center text-orange-500 mb-4 animate-bounce">
                    <Check className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">Submission Successful!</h3>
                  <p className="text-neutral-400 text-sm mt-1">
                    We'll reach out within the next 24 business hours.
                  </p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-neutral-400 mb-1.5">
                      Your Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sarah Connor"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg px-3 py-2.5 text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-neutral-400 mb-1.5">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. sarah@cyberdyne.io"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg px-3 py-2.5 text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-semibold text-neutral-400 mb-1.5">
                      Project Goals (Optional)
                    </label>
                    <textarea
                      placeholder="Briefly describe what you'd like to build..."
                      rows={3}
                      value={formData.project}
                      onChange={(e) => setFormData({ ...formData, project: e.target.value })}
                      className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg px-3 py-2.5 text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500 transition-colors resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white rounded-lg py-3 text-sm font-semibold transition-all duration-300 shadow-[0_4px_20px_rgba(249,115,22,0.15)] mt-2 cursor-pointer"
                  >
                    Send Brief
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
